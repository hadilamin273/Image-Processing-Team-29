// --- PIN DEFINITIONS FOR 2x L298N ---

// Driver 1, OUT1/OUT2 → Front Right motor (+ve = OUT2)
const int FR_EN  = 27; const int FR_IN1 = 13; const int FR_IN2 = 14;

// Driver 1, OUT3/OUT4 → Front Left motor (+ve = OUT4)
const int FL_EN  = 12; const int FL_IN3 = 26; const int FL_IN4 = 25;

// Driver 2, OUT1/OUT2 → Left Rear motor (+ve = OUT2)
const int RL_EN  = 33; const int RL_IN1 = 32; const int RL_IN2 = 35;

// Driver 2, OUT3/OUT4 → Right Rear motor (+ve = OUT4)
const int RR_EN  = 23; const int RR_IN3 = 22; const int RR_IN4 = 21;

void setup() {
  Serial.begin(115200);

  int pins[] = {FR_EN, FR_IN1, FR_IN2,
                FL_EN, FL_IN3, FL_IN4,
                RL_EN, RL_IN1, RL_IN2,
                RR_EN, RR_IN3, RR_IN4};

  for (int i = 0; i < 12; i++) pinMode(pins[i], OUTPUT);

  Serial.println("Team 21 - Dual L298N Controller Ready");
}

void loop() {
  if (Serial.available() > 0) {
    String data = Serial.readStringUntil('\n');

    if (data.startsWith("MOVE")) {
      int firstComma  = data.indexOf(',');
      int secondComma = data.indexOf(',', firstComma + 1);
      int thirdComma  = data.indexOf(',', secondComma + 1);

      int forward  = data.substring(firstComma + 1,  secondComma).toInt();
      int strafe   = data.substring(secondComma + 1, thirdComma).toInt();
      int rotation = data.substring(thirdComma + 1).toInt();

      driveMecanum(forward, strafe, rotation);
    }
  }
}

void driveMecanum(int forward, int strafe, int rotation) {
  int fl = forward + strafe + rotation;
  int fr = forward - strafe - rotation;
  int rl = forward - strafe + rotation;
  int rr = forward + strafe - rotation;

  // Pass the +ve pin FIRST so speed>0 drives the motor forward
  controlMotor(FR_EN, FR_IN2, FR_IN1, fr);  // +ve = OUT2 → IN2 first
  controlMotor(FL_EN, FL_IN4, FL_IN3, fl);  // +ve = OUT4 → IN4 first
  controlMotor(RL_EN, RL_IN2, RL_IN1, rl);  // +ve = OUT2 → IN2 first
  controlMotor(RR_EN, RR_IN4, RR_IN3, rr);  // +ve = OUT4 → IN4 first
}

void controlMotor(int enPin, int inPos, int inNeg, int speed) {
  int absSpeed = constrain(abs(speed), 0, 255);

  if (speed > 0) {
    digitalWrite(inPos, HIGH);
    digitalWrite(inNeg, LOW);
  } else if (speed < 0) {
    digitalWrite(inPos, LOW);
    digitalWrite(inNeg, HIGH);
  } else {
    digitalWrite(inPos, LOW);
    digitalWrite(inNeg, LOW);
  }
  analogWrite(enPin, absSpeed);
}